import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './FxCalculator.css';

class FxCalculator extends React.Component{
    constructor(props){
        super(props);
        this.state = {result:""};
        this.inputFxRef = React.createRef()
        this.covertingFxRef = React.createRef()
    }
    FxCalculatorClear = (e) => {
        e.preventDefault();
        this.inputFxRef.current.value = "";
        this.covertingFxRef.current.value = "";
        this.setState({result:""});
    }
FxCalculator = (e) => {
    e.preventDefault();
    if (this.inputFxRef.current.value !== "" && this.covertingFxRef.current.value) {
        var USD = {
            "AUD": 0.8371,
            "CAD": 0.8711,
            "CNY": 0.1620,
            "EUR": 1.2315,
            "GBP": 1.5683,
            "NZD": 0.7750,
            "JPY": 0.0083,
            "CZK": 0.0446,
            "DKK": 0.1655,
            "NOK": 0.1421
        };
        var convertedvalue;
        var inputvalueforconverting = this.inputFxRef.current.value.split(" ");
        var inputvalueforconvertingtounit = this.covertingFxRef.current.value.toUpperCase();
        var inputvalueforconvertingunit = inputvalueforconverting[0].toUpperCase();
        var inputvalueforconvertingnumber = parseFloat(inputvalueforconverting[1]);
    
    
        if (inputvalueforconvertingunit === inputvalueforconvertingtounit) {
            convertedvalue = inputvalueforconvertingnumber;
        } else if (inputvalueforconvertingunit === "USD" || inputvalueforconvertingtounit === "USD") {
            if (inputvalueforconvertingunit === "USD") {
                convertedvalue = inputvalueforconvertingnumber / USD[inputvalueforconvertingtounit];
            } else {
                convertedvalue = inputvalueforconvertingnumber * USD[inputvalueforconvertingunit];
            }
    
        } else if (typeof(USD[inputvalueforconvertingunit]) === "undefined" || typeof(USD[inputvalueforconvertingtounit]) === "undefined") {
            alert("Unable to find rate for " + inputvalueforconvertingunit + "/" + inputvalueforconvertingtounit);
        } else if (inputvalueforconvertingunit !== inputvalueforconvertingtounit) {
            var usdvalueofconvertingnumber = inputvalueforconvertingnumber * USD[inputvalueforconvertingunit];
            convertedvalue = usdvalueofconvertingnumber / USD[inputvalueforconvertingtounit];
        }
        if (inputvalueforconvertingtounit === "JPY") {
            convertedvalue = parseInt(convertedvalue);
            convertedvalue = "Converted Value: " + inputvalueforconvertingtounit + " " + convertedvalue;
            this.setState({
                result: convertedvalue
            });
        } else if (typeof(USD[inputvalueforconvertingunit]) !== "undefined" && typeof(USD[inputvalueforconvertingtounit]) !== "undefined") {
            convertedvalue = convertedvalue.toFixed(2);
            convertedvalue = "Converted Value: " + inputvalueforconvertingtounit + " " + convertedvalue;
            this.setState({
                result: convertedvalue
            });
        }
    
    }


}
    render(){
        return(
            <React.Fragment>
            <form>
               <div className="Fx-Calculator col-12">
                  <div className="form-group">
                     <label>From :</label>
                     <input type="text" className="form-control 
                        Fx-Calculator-Converting-Input-Value" placeholder = "AUD 100" ref={this.inputFxRef}/>
                  </div>
                  <div className="form-group Converting-Unit-Container">
                     <label>To :</label>
                     <input type="text" className="form-control
                        Fx-Calculator-Converting-Input-Value-To" placeholder = "AUD" ref={this.covertingFxRef}/>
                  </div>
                  <p className="Converted-Value-Result">{this.state.result}</p>
                  <div className ="Buttons-Container">
                     <button className="Fx-Calculator-Submit-Button" onClick ={(e) => this.FxCalculator(e)}>Submit</button>
                     <button className="Fx-Calculator-Clear-Button"  onClick ={(e) => this.FxCalculatorClear(e)}>Clear</button>
                  </div>
               </div>
            </form>
         </React.Fragment>
        )
    
    }
        
}

export default FxCalculator;